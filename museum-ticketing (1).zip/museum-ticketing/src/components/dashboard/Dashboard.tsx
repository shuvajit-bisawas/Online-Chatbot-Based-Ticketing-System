"use client";

import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CalendarIcon, ArrowUpDown, Users, Clock, Info, Calendar, TrendingUp } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface VisitorLog {
  id: string;
  date: string;
  visitors: number;
  details: string;
  timeDistribution?: {
    morning: number;
    afternoon: number;
    evening: number;
  };
  demographics?: {
    adults: number;
    children: number;
    seniors: number;
  };
  revenue?: number;
  popularExhibits?: string[];
}

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<string>('daily');
  const [dailyLogs, setDailyLogs] = useState<VisitorLog[]>([]);
  const [monthlyLogs, setMonthlyLogs] = useState<VisitorLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  useEffect(() => {
    // Enhanced simulated data for demonstration purposes
    const simulatedDailyLogs = [
      { 
        id: '1', 
        date: '2025-05-13', 
        visitors: 120, 
        details: 'School group visit from Green Valley High School, guided tour included.',
        timeDistribution: { morning: 80, afternoon: 40, evening: 0 },
        demographics: { adults: 8, children: 105, seniors: 7 },
        revenue: 1800,
        popularExhibits: ['Ancient Artifacts', 'Dinosaur Gallery', 'Interactive Science Zone']
      },
      { 
        id: '2', 
        date: '2025-05-12', 
        visitors: 95, 
        details: 'Regular visitors, including families and individual tourists.',
        timeDistribution: { morning: 25, afternoon: 45, evening: 25 },
        demographics: { adults: 58, children: 22, seniors: 15 },
        revenue: 1425,
        popularExhibits: ['Modern Art', 'Photography Exhibit', 'Sculpture Garden']
      },
      { 
        id: '3', 
        date: '2025-05-11', 
        visitors: 150, 
        details: 'Weekend crowd with a special art exhibition event.',
        timeDistribution: { morning: 45, afternoon: 80, evening: 25 },
        demographics: { adults: 98, children: 37, seniors: 15 },
        revenue: 2250,
        popularExhibits: ['Special Exhibition: Renaissance Masters', 'Sculpture Garden', 'Cafe Gallery']
      },
      { 
        id: '4', 
        date: '2025-05-10', 
        visitors: 80, 
        details: 'Rainy day, fewer visitors than usual.',
        timeDistribution: { morning: 15, afternoon: 45, evening: 20 },
        demographics: { adults: 42, children: 18, seniors: 20 },
        revenue: 1200,
        popularExhibits: ['Indoor Exhibitions', 'Museum Theater', 'Library Collection']
      },
      { 
        id: '5', 
        date: '2025-05-09', 
        visitors: 110, 
        details: 'Corporate group visit from TechCorp, team-building activity.',
        timeDistribution: { morning: 0, afternoon: 110, evening: 0 },
        demographics: { adults: 104, children: 0, seniors: 6 },
        revenue: 2750,
        popularExhibits: ['Modern Art', 'Innovation Gallery', 'Private Tour']
      },
    ];

    const simulatedMonthlyLogs = [
      { 
        id: '1', 
        date: '2025-04', 
        visitors: 3000, 
        details: 'April summary: Increased footfall due to spring break and art festival.',
        demographics: { adults: 1750, children: 950, seniors: 300 },
        revenue: 45000,
        popularExhibits: ['Spring Art Festival', 'Dinosaur Gallery', 'Interactive Science Zone']
      },
      { 
        id: '2', 
        date: '2025-03', 
        visitors: 2800, 
        details: 'March summary: Regular visitors and a special science exhibition.',
        demographics: { adults: 1600, children: 850, seniors: 350 },
        revenue: 42000,
        popularExhibits: ['Science Exhibition', 'Ancient Artifacts', 'Modern Art']
      },
      { 
        id: '3', 
        date: '2025-02', 
        visitors: 2500, 
        details: "February summary: Valentine's Day event attracted couples and families.",
        demographics: { adults: 1700, children: 500, seniors: 300 },
        revenue: 37500,
        popularExhibits: ['Romance Through Ages', 'Modern Art', 'Sculpture Garden']
      },
      { 
        id: '4', 
        date: '2025-01', 
        visitors: 2200, 
        details: 'January summary: New Year celebrations and winter vacation visitors.',
        demographics: { adults: 1200, children: 750, seniors: 250 },
        revenue: 33000,
        popularExhibits: ['Winter Special Exhibition', 'Dinosaur Gallery', 'Cultural History']
      },
      { 
        id: '5', 
        date: '2024-12', 
        visitors: 3500, 
        details: 'December summary: Holiday season with Christmas and New Year events.',
        demographics: { adults: 1950, children: 1200, seniors: 350 },
        revenue: 52500,
        popularExhibits: ['Holiday Special', 'Winter Wonderland', 'Gift Shop Exhibition']
      },
    ];

    setDailyLogs(simulatedDailyLogs);
    setMonthlyLogs(simulatedMonthlyLogs);
    setLoading(false);
  }, []);

  const handleSort = () => {
    const newOrder = sortOrder === 'asc' ? 'desc' : 'asc';
    setSortOrder(newOrder);

    const sortedDaily = [...dailyLogs].sort((a, b) => {
      return sortOrder === 'asc' 
        ? new Date(a.date).getTime() - new Date(b.date).getTime() 
        : new Date(b.date).getTime() - new Date(a.date).getTime();
    });

    const sortedMonthly = [...monthlyLogs].sort((a, b) => {
      return sortOrder === 'asc'
        ? new Date(a.date).getTime() - new Date(b.date).getTime()
        : new Date(b.date).getTime() - new Date(a.date).getTime();
    });

    setDailyLogs(sortedDaily);
    setMonthlyLogs(sortedMonthly);
  };

  // Calculate total visitors and average per day/month
  const totalDailyVisitors = dailyLogs.reduce((sum: number, log: VisitorLog) => sum + log.visitors, 0);
  const avgDailyVisitors = dailyLogs.length > 0 ? Math.round(totalDailyVisitors / dailyLogs.length) : 0;
  
  const totalMonthlyVisitors = monthlyLogs.reduce((sum: number, log: VisitorLog) => sum + log.visitors, 0);
  const avgMonthlyVisitors = monthlyLogs.length > 0 ? Math.round(totalMonthlyVisitors / monthlyLogs.length) : 0;

  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-2">Visitor Logs Dashboard</h1>
      <p className="text-muted-foreground mb-6">Track and analyze museum visitor statistics</p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Visitors
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Users className="h-5 w-5 text-primary mr-2" />
              <div className="text-2xl font-bold">
                {activeTab === 'daily' ? totalDailyVisitors : totalMonthlyVisitors}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Average Per {activeTab === 'daily' ? 'Day' : 'Month'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <TrendingUp className="h-5 w-5 text-primary mr-2" />
              <div className="text-2xl font-bold">
                {activeTab === 'daily' ? avgDailyVisitors : avgMonthlyVisitors}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Date Range
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Calendar className="h-5 w-5 text-primary mr-2" />
              <div className="text-2xl font-bold">
                {activeTab === 'daily' ? 
                  (dailyLogs.length > 0 ? `Last ${dailyLogs.length} Days` : 'No data') : 
                  (monthlyLogs.length > 0 ? `Last ${monthlyLogs.length} Months` : 'No data')}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <div className="flex justify-between items-center">
          <TabsList>
            <TabsTrigger value="daily">Daily Logs</TabsTrigger>
            <TabsTrigger value="monthly">Monthly Logs</TabsTrigger>
          </TabsList>
          
          <Button variant="outline" size="sm" onClick={handleSort} className="ml-auto">
            <ArrowUpDown className="h-4 w-4 mr-2" />
            {sortOrder === 'desc' ? 'Newest First' : 'Oldest First'}
          </Button>
        </div>

        <TabsContent value="daily" className="mt-4">
          {loading ? (
            <div className="flex justify-center items-center h-32">
              <p>Loading daily logs...</p>
            </div>
          ) : dailyLogs.length > 0 ? (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-2">
              {dailyLogs.map((log) => (
                <Card key={log.id} className="overflow-hidden">
                  <CardHeader className="bg-muted/20">
                    <div className="flex justify-between items-center">
                      <div>
                        <CardTitle className="flex items-center">
                          <CalendarIcon className="h-4 w-4 mr-2" /> {log.date}
                        </CardTitle>
                        <CardDescription>Daily visitor log</CardDescription>
                      </div>
                      <Badge variant={log.visitors > 100 ? "default" : "secondary"}>
                        {log.visitors} Visitors
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-medium flex items-center">
                          <Info className="h-4 w-4 mr-2 text-muted-foreground" />Details
                        </h3>
                        <p className="text-sm mt-1">{log.details}</p>
                      </div>

                      {log.timeDistribution && (
                        <div>
                          <h3 className="font-medium flex items-center">
                            <Clock className="h-4 w-4 mr-2 text-muted-foreground" />Time Distribution
                          </h3>
                          <div className="grid grid-cols-3 gap-2 mt-1">
                            <div className="text-center p-1 bg-muted/20 rounded">
                              <p className="text-xs text-muted-foreground">Morning</p>
                              <p className="font-medium">{log.timeDistribution.morning}</p>
                            </div>
                            <div className="text-center p-1 bg-muted/20 rounded">
                              <p className="text-xs text-muted-foreground">Afternoon</p>
                              <p className="font-medium">{log.timeDistribution.afternoon}</p>
                            </div>
                            <div className="text-center p-1 bg-muted/20 rounded">
                              <p className="text-xs text-muted-foreground">Evening</p>
                              <p className="font-medium">{log.timeDistribution.evening}</p>
                            </div>
                          </div>
                        </div>
                      )}

                      {log.demographics && (
                        <div>
                          <h3 className="font-medium flex items-center">
                            <Users className="h-4 w-4 mr-2 text-muted-foreground" />Demographics
                          </h3>
                          <div className="grid grid-cols-3 gap-2 mt-1">
                            <div className="text-center p-1 bg-muted/20 rounded">
                              <p className="text-xs text-muted-foreground">Adults</p>
                              <p className="font-medium">{log.demographics.adults}</p>
                            </div>
                            <div className="text-center p-1 bg-muted/20 rounded">
                              <p className="text-xs text-muted-foreground">Children</p>
                              <p className="font-medium">{log.demographics.children}</p>
                            </div>
                            <div className="text-center p-1 bg-muted/20 rounded">
                              <p className="text-xs text-muted-foreground">Seniors</p>
                              <p className="font-medium">{log.demographics.seniors}</p>
                            </div>
                          </div>
                        </div>
                      )}

                      {log.popularExhibits && (
                        <div>
                          <h3 className="font-medium">Popular Exhibits</h3>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {log.popularExhibits.map((exhibit, i) => (
                              <Badge key={i} variant="outline">{exhibit}</Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* {log.revenue && (
                        <div className="flex justify-between items-center pt-2 border-t">
                          <p className="text-sm text-muted-foreground">Revenue</p>
                          <p className="font-medium">${log.revenue.toLocaleString()}</p>
                        </div>
                      )} */}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center h-32">
                <p>No daily logs available.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="monthly" className="mt-4">
          {loading ? (
            <div className="flex justify-center items-center h-32">
              <p>Loading monthly logs...</p>
            </div>
          ) : monthlyLogs.length > 0 ? (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-2">
              {monthlyLogs.map((log) => (
                <Card key={log.id} className="overflow-hidden">
                  <CardHeader className="bg-muted/20">
                    <div className="flex justify-between items-center">
                      <div>
                        <CardTitle className="flex items-center">
                          <CalendarIcon className="h-4 w-4 mr-2" /> {log.date}
                        </CardTitle>
                        <CardDescription>Monthly summary</CardDescription>
                      </div>
                      <Badge variant="default">
                        {log.visitors.toLocaleString()} Visitors
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-medium flex items-center">
                          <Info className="h-4 w-4 mr-2 text-muted-foreground" />Summary
                        </h3>
                        <p className="text-sm mt-1">{log.details}</p>
                      </div>

                      {log.demographics && (
                        <div>
                          <h3 className="font-medium flex items-center">
                            <Users className="h-4 w-4 mr-2 text-muted-foreground" />Visitor Demographics
                          </h3>
                          <div className="grid grid-cols-3 gap-2 mt-1">
                            <div className="text-center p-2 bg-muted/20 rounded">
                              <p className="text-xs text-muted-foreground">Adults</p>
                              <p className="font-medium">{log.demographics.adults.toLocaleString()}</p>
                            </div>
                            <div className="text-center p-2 bg-muted/20 rounded">
                              <p className="text-xs text-muted-foreground">Children</p>
                              <p className="font-medium">{log.demographics.children.toLocaleString()}</p>
                            </div>
                            <div className="text-center p-2 bg-muted/20 rounded">
                              <p className="text-xs text-muted-foreground">Seniors</p>
                              <p className="font-medium">{log.demographics.seniors.toLocaleString()}</p>
                            </div>
                          </div>
                        </div>
                      )}

                      {log.popularExhibits && (
                        <div>
                          <h3 className="font-medium">Top Attractions</h3>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {log.popularExhibits.map((exhibit, i) => (
                              <Badge key={i} variant="outline">{exhibit}</Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {log.revenue && (
                        <div className="flex justify-between items-center pt-2 border-t">
                          <p className="text-sm text-muted-foreground">Total Revenue</p>
                          <p className="font-medium">${log.revenue.toLocaleString()}</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center h-32">
                <p>No monthly logs available.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}